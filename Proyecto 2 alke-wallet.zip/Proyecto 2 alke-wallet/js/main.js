// --- ALKE WALLET (versión simple) ---
// Guardamos el saldo y los movimientos en localStorage para que "se mantenga" entre pantallas.

function getSaldo() {
  let saldo = localStorage.getItem("saldo");
  if (saldo === null) {
    saldo = 60000; // saldo inicial como en tu menu.html
    localStorage.setItem("saldo", saldo);
  }
  return parseFloat(saldo);
}

function setSaldo(nuevoSaldo) {
  localStorage.setItem("saldo", nuevoSaldo);
}

function getMovimientos() {
  let movs = localStorage.getItem("movimientos");
  if (movs === null) {
    // Movimientos iniciales como los que tenías
    const iniciales = [
      "Depósito | $100000",
      "Transferencia recibida | $75000",
      "Depósito misma cuenta | $10000",
      "Transferencia recibida | $757500",
    ];
    localStorage.setItem("movimientos", JSON.stringify(iniciales));
    return iniciales;
  }
  return JSON.parse(movs);
}

function addMovimiento(texto) {
  const movs = getMovimientos();
  movs.unshift(texto);
  localStorage.setItem("movimientos", JSON.stringify(movs));
}

// --- MENU ---
function mostrarSaldoEnMenu() {
  const saldo = getSaldo();
  const saldoEl = document.getElementById("balanceValue");
  if (saldoEl) {
    saldoEl.textContent = "$" + saldo.toFixed(0);
  }
}

// --- LOGIN (simple) ---
function loginSimple() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const mensaje = document.getElementById("mensaje");

  // Credenciales permitidas
  const emailPermitido = "camila@gmail.com";
  const passwordPermitida = "1234";

  if (email === emailPermitido && password === passwordPermitida) {
    mensaje.textContent = "";
    alert("Inicio de sesión correcto");
    // redirigir si quieres
    window.location.href = "menu.html";
  } else {
    mensaje.textContent = "Correo o contraseña incorrectos";
  }
}


// --- DEPOSITAR ---
function depositarSimple() {
  const input = document.getElementById("depositAmount");
  const monto = parseFloat(input.value);

  if (isNaN(monto) || monto <= 0) {
    alert("Ingresa un monto válido.");
    return;
  }

  const saldo = getSaldo();
  const nuevoSaldo = saldo + monto;
  setSaldo(nuevoSaldo);

  addMovimiento("Depósito | $" + monto.toFixed(0));
  alert("Depósito realizado ✅\nNuevo saldo: $" + nuevoSaldo.toFixed(0));

  input.value = "";
}

// --- ENVIAR DINERO (simple) ---
function enviarDineroSimple() {
  const montoEl = document.getElementById("sendAmount");
  const monto = parseFloat(montoEl.value);

  if (isNaN(monto) || monto <= 0) {
    alert("Ingresa un monto válido para enviar.");
    return;
  }

  const saldo = getSaldo();
  if (monto > saldo) {
    alert("No tienes saldo suficiente.");
    return;
  }

  const nuevoSaldo = saldo - monto;
  setSaldo(nuevoSaldo);

  addMovimiento("Transferencia enviada | - $" + monto.toFixed(0));
  alert("Dinero enviado ✅\nNuevo saldo: $" + nuevoSaldo.toFixed(0));

  montoEl.value = "";
}
// --- BUSCAR CONTACTO ---
function buscarContacto() {
  const input = document.getElementById("searchContact").value.toLowerCase();
  const lista = document.getElementById("contactList");
  const contactos = lista.getElementsByTagName("li");

  for (let i = 0; i < contactos.length; i++) {
    const nombre = contactos[i]
      .querySelector(".contact-name")
      .textContent
      .toLowerCase();

    if (nombre.includes(input)) {
      contactos[i].style.display = "";
    } else {
      contactos[i].style.display = "none";
    }
  }
}

// --- TRANSACCIONES ---
function cargarMovimientos() {
  const lista = document.getElementById("transactionsList");
  if (!lista) return;

  const movs = getMovimientos();
  lista.innerHTML = "";

  movs.forEach((m) => {
    const li = document.createElement("li");
    li.className = "list-group-item";
    li.textContent = m;
    lista.appendChild(li);
  });
}

// --- AUTO INIT ---
document.addEventListener("DOMContentLoaded", function () {
  mostrarSaldoEnMenu();
  cargarMovimientos();
});
